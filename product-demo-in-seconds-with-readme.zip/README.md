# 🚀 Product Demo in Seconds

Create branded product demo videos instantly by uploading screenshots and logos.

## ✨ Features
- Upload multiple screenshots
- Add your logo
- Pick a brand color
- Automatically generate demo video using FFmpeg in the browser

## 🛠️ Technologies
- Next.js 13
- React
- Tailwind CSS
- @ffmpeg/ffmpeg
- react-dropzone
- react-colorful

## 🔧 How to Run Locally

```bash
git clone https://github.com/your-username/product-demo-in-seconds.git
cd product-demo-in-seconds
npm install
npm run dev
```

## 🧪 Demo Walkthrough
1. Upload product screenshots
2. Upload your company logo
3. Select brand color
4. The app generates a video with your branding

---

Made with ❤️ and deployed using [Vercel](https://vercel.com/)
