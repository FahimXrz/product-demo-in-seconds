import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      <h1 className="text-4xl font-bold mb-4">🚀 Product Demo in Seconds</h1>
      <p className="mb-6 text-center text-lg">Upload screenshots and create a branded product demo video easily.</p>
      <Link href="/studio">
        <button className="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition">Get Started</button>
      </Link>
    </div>
  );
}