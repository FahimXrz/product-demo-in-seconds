import { useState } from "react";
import UploadZone from "../components/UploadZone";
import LogoUploader from "../components/LogoUploader";
import BrandSettings from "../components/BrandSettings";
import VideoGenerator from "../components/VideoGenerator";

export default function Studio() {
  const [screenshots, setScreenshots] = useState<File[]>([]);
  const [logo, setLogo] = useState<File | null>(null);
  const [brandColor, setBrandColor] = useState("#3B82F6");

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">🎞️ Create Your Product Demo</h1>
      <UploadZone onDrop={(files) => setScreenshots(files)} />
      <LogoUploader onChange={(file) => setLogo(file)} />
      <BrandSettings color={brandColor} setColor={setBrandColor} />
      {screenshots.length > 0 && logo && (
        <div className="mt-6">
          <VideoGenerator screenshots={screenshots} logo={logo} />
        </div>
      )}
    </div>
  );
}