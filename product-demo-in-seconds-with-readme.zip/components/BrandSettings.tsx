import { HexColorPicker } from "react-colorful";

export default function BrandSettings({ color, setColor }: { color: string; setColor: (c: string) => void }) {
  return (
    <div className="my-4">
      <label className="block mb-2 font-semibold">🎨 Pick brand color:</label>
      <HexColorPicker color={color} onChange={setColor} />
    </div>
  );
}