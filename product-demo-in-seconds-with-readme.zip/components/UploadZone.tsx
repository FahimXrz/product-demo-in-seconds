import { useDropzone } from "react-dropzone";

export default function UploadZone({ onDrop }: { onDrop: (files: File[]) => void }) {
  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept: { "image/*": [] },
  });

  return (
    <div
      {...getRootProps()}
      className="p-6 border-2 border-dashed rounded-xl text-center cursor-pointer my-4"
    >
      <input {...getInputProps()} />
      <p>📷 Upload screenshots or drag & drop here</p>
    </div>
  );
}