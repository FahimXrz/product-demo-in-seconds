import { useEffect, useState } from "react";
import { createFFmpeg, fetchFile } from "@ffmpeg/ffmpeg";

export default function VideoGenerator({ screenshots, logo }: { screenshots: File[]; logo: File }) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [videoUrl, setVideoUrl] = useState("");
  const ffmpeg = createFFmpeg({ log: true });

  const generateVideo = async () => {
    setIsProcessing(true);
    await ffmpeg.load();
    ffmpeg.FS("writeFile", "logo.png", await fetchFile(logo));
    for (let i = 0; i < screenshots.length; i++) {
      ffmpeg.FS("writeFile", `screenshot${i}.png`, await fetchFile(screenshots[i]));
    }

    await ffmpeg.run(
      "-framerate", "1",
      "-i", "screenshot%d.png",
      "-i", "logo.png",
      "-filter_complex", "[0][1]overlay=10:10",
      "-c:v", "libx264",
      "-pix_fmt", "yuv420p",
      "-r", "30",
      "output.mp4"
    );

    const data = ffmpeg.FS("readFile", "output.mp4");
    const videoBlob = new Blob([data.buffer], { type: "video/mp4" });
    const videoUrl = URL.createObjectURL(videoBlob);
    setVideoUrl(videoUrl);
    setIsProcessing(false);
  };

  useEffect(() => {
    if (screenshots.length && logo) generateVideo();
  }, [screenshots, logo]);

  return (
    <div>
      {isProcessing ? (
        <p>Generating video...</p>
      ) : (
        videoUrl && <video src={videoUrl} controls className="w-full" />
      )}
    </div>
  );
}