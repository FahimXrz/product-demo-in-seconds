export default function LogoUploader({ onChange }: { onChange: (file: File) => void }) {
  return (
    <div className="my-4">
      <label className="block mb-2 font-semibold">🖼️ Upload your logo:</label>
      <input
        type="file"
        accept="image/*"
        onChange={(e) => {
          if (e.target.files && e.target.files[0]) onChange(e.target.files[0]);
        }}
      />
    </div>
  );
}